function [iminter,X]=GetInterImg1(im);

im = double(im);
[size1,size2] = size(im);

iminter = im;
iminter(1,1) = (im(1,2)+im(2,1))/2;
iminter(1,size2) = (im(1,size2-1)+im(2,size2))/2;
iminter(size1,size2) = (im(size1,size2-1)+im(size1-1,size2))/2;
iminter(size1,1) = (im(size1,2)+im(size1-1,1))/2;
iminter(1,2:size2-1) = (im(1,1:size2-2)+im(1,3:size2)+im(2,2:size2-1))/3;
iminter(2:size1-1,1) = (im(2:size1-1,2)+im(1:size1-2,1)+im(3:size1,1))/3;
iminter(size1,2:size2-1) = (im(size1,1:size2-2)+im(size1,3:size2)+im(size1-1,2:size2-1))/3;
iminter(2:size1-1,size2) = (im(2:size1-1,size2-1)+im(1:size1-2,size2)+im(3:size1,size2))/3;

for i = 2:size1-1
    for j = 2:size2-1         
        t1 = (im(i+1,j)+im(i-1,j))/2;
        t2 = (im(i,j+1)+im(i,j-1))/2;
        t0 = (t1+t2)/2;
        sig1 = mean(([im(i+1,j) im(i-1,j) t1] - t0).^2);  % sqrt(mean(abs([im(i+1,j) im(i-1,j)]-t1).^2));        
        sig2 = mean(([im(i,j+1) im(i,j-1) t2] - t0).^2);   % sqrt(mean(abs([im(i,j+1) im(i,j-1)]-t2).^2));
        if sig1+sig2 == 0
            iminter(i,j) = t0;
        else
            w1 = sig2/(sig1+sig2);
            iminter(i,j) = t1 * w1 + t2 * (1-w1);               
        end
    end
end

iminter = round(iminter);