function [HMat, Payl, Dist, drate, L, R, CHist] = GetHMat(Err);

% OriHist = [0 0 0 0 5 20 61 58 18 4 0 0 0 0];
% im = imread('lena.bmp');
% im = double(im);
% Err = round((im(1:510,2:511)+im(3:512,2:511)+im(2:511,1:510)+im(2:511,3:512))/4-im(2:511,2:511));

OriHist = hist(Err(:),[min(min(Err)):1:max(max(Err))]);

sumhist = sum(OriHist);
temph = sign(OriHist - sumhist/1000);
[vmax, indmx] = max(temph);

for k = indmx:length(OriHist)
    if temph(k) == 1
        indmx1 = k;
    end
end

L = min(min(Err))+indmx-1;
R = min(min(Err))+indmx1-1;

sumhist = sum(OriHist);
CHist = round(OriHist/(sumhist/1024));
OriHist = [zeros(1,20) CHist(1,indmx:indmx1) zeros(1,20)];


LH = length(OriHist);

HMat = zeros(LH,LH);
for k = 1:LH
    HMat(k,k) = OriHist(k);
end

delta = 0.2;
for k = 1:3500
    drate = 0;
    for i = 1:LH
%         tempd1 = 0;
%         for j = 1:LH
%             tempd1 = tempd1 + HMat(i,j)*(j-i)^2;
%         end
        for j = 1:LH
            if HMat(i,j) >= delta   
                if i == j
                    jjmin = i - 5; 
                    jjmax = i + 5;
                else
                    if j > i
                        jjmin = j + 1;
                        jjmax = j + 5;
                    else
                        jjmin = j - 5;
                        jjmax = j - 1;
                    end
                end
                for jj = jjmin:jjmax  % j-5:j+5 % 1:LH                    
                    HMat1 = HMat;
                    tempp1 = GetEntropy(HMat1(i,1:LH))-GetEntropy(HMat1(1:LH,j))-GetEntropy(HMat1(1:LH,jj));
                    HMat1(i,j) = HMat1(i,j) - delta;
                    HMat1(i,jj) = HMat1(i,jj) + delta;
                    tempp2 = GetEntropy(HMat1(i,1:LH))-GetEntropy(HMat1(1:LH,j))-GetEntropy(HMat1(1:LH,jj));
%                     tempd2 = 0;
%                     for kk = 1:LH
%                         tempd2 = tempd2 + HMat1(i,kk)*(kk-i)^2;
%                     end
                    dp = tempp2 - tempp1;
                    dd = (jj-i)^2 - (j-i)^2;
%                     disp([i j jj dp dd]);
                    if dp > 0
%                         if dd == 0;
%                             dd = 0.000000000001;
%                         end
                        dratetemp = dp/dd;
                        if dratetemp > drate                            
                            drate = dratetemp;
                            di = i; dj = j; djj = jj;
                            
                        end
                    end
                end
            end
        end
    end
%      disp([di dj djj drate]);
    HMat(di,dj) = HMat(di,dj) - delta;
    HMat(di,djj) = HMat(di,djj) + delta;
end    
    
    Dist = 0;
    for i = 1:LH
        for j = 1:LH
            Dist = Dist + HMat(i,j)*(j-i)^2;
        end
    end
    Payl = 0;
    for i = 1:LH
        Payl = Payl + GetEntropy (HMat(i,:));
    end
    for j = 1:LH
        Payl = Payl - GetEntropy (HMat(:,j));
    end
    [Payl Dist]

                        