function [stegoim1,P1,P2,number0255,number0255r]=ReverEmbed(Err1,im1,HMat, Payl, Dist, drate, L, R, CHist);

stegoim1 = im1;
[size1,size2] = size(Err1);
HMatFold = sum(HMat);

P1 = 0;
P2 = 0;
P21 = 0; P22 = 0; P23 = 0; P24 = 0; P25 = 0; 
number0255 = 0;
number0255r = 0;
for i = 1:size1
    for j = 1:size2
        tempe = Err1(i,j);
        tempp = im1(i,j);
        if tempe < L
            tempv = tempe-L+21;
            if tempv > 0
                if HMatFold(tempv) > 0
                    P21 = P21 - log(0.5/(0.5+HMatFold(tempv)))/log(2);
                end
            end
        else
            if tempe > R
                tempv = tempe-L+21;
                if tempv < length(HMatFold)+1
                    P22 = P22 - log(0.5/(0.5+HMatFold(tempv)))/log(2);
                end
            else
                fnz = find(HMat(tempe-L+21,:));
                vnz = nonzeros(HMat(tempe-L+21,:));
                vnz = vnz';
                fnz = fnz - (tempe-L+21) + tempp; 
                if min(fnz) > 255
                    stegoim1(i,j) = 255;
                    number0255 = number0255 + 1;
                    number0255r = number0255r + 1;
                else
                    if max(fnz) < 0
                        stegoim1(i,j) = 0;
                        number0255 = number0255 + 1;
                        number0255r = number0255r + 1;
                    else
                        msk1 = (sign(fnz + 0.5) + 1)/2;
                        msk2 = (sign(255.5 - fnz) + 1)/2;
                        msk = msk1 .* msk2;
                        fnz = msk .* fnz;
                        vnz = msk .* vnz;
                        vnz = vnz/sum(vnz);
                        rand('seed',i*2001+j);
                        tempa = rand(1,1);
                        tempb = 0; tempc = 0;
                        while tempb < tempa
                            tempc = tempc + 1;
                            tempb = tempb + vnz(tempc);
                        end
                        tempc;
                        P1 = P1 - log(vnz(tempc))/log(2);
                        stegoim1(i,j) = fnz(tempc);
                        if fnz(tempc) == 0
                            number0255 = number0255 + 1;
                        end
                        if fnz(tempc) == 255
                            number0255 = number0255 + 1;
                        end
                        tempd = fnz(tempc) - tempp + (tempe-L+21);
                        if tempd < 21
                            P23 = P23 - log(HMat(tempe-L+21,tempd)/(0.5+HMatFold(tempd)))/log(2);
                        else
                            if tempd > length(HMatFold) - 20
                                P24 = P24 - log(HMat(tempe-L+21,tempd)/(0.5+HMatFold(tempd)))/log(2);
                            else
                                P25 = P25 - log(HMat(tempe-L+21,tempd)/HMatFold(tempd))/log(2);
                            end
                        end
                    end
                end
            end
        end
    end
end                   
% disp([P21 P22 P23 P24 P25]);
P2 = P21+P22+P23+P24+P25;
                    